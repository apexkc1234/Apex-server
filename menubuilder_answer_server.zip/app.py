import json
import os
import sqlite3
from contextlib import closing
from typing import Any

from fastapi import FastAPI, Header, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field

DB_PATH = os.getenv("DB_PATH", "answers.db")
API_SECRET = os.getenv("API_SECRET", "")

app = FastAPI(title="MenuBuilder Answer Server", version="1.0.0")


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS answers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            question_id TEXT NOT NULL,
            answer TEXT NOT NULL
        )
    """)
    conn.commit()
    return conn


class Answer(BaseModel):
    model_config = ConfigDict(extra="ignore")
    user_id: str = Field(min_length=1, max_length=100)
    question_id: str = Field(min_length=1, max_length=200)
    answer: Any


def check_secret(x_api_secret: str | None):
    if not API_SECRET:
        raise HTTPException(status_code=500, detail="Server API_SECRET is not configured")
    if x_api_secret != API_SECRET:
        raise HTTPException(status_code=401, detail="Unauthorized")


def clean_answer(value: Any) -> str:
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    return str(value)


@app.get("/health")
def health():
    return {"ok": True}


@app.post("/api/v1/answer")
def save_answer(payload: Answer, x_api_secret: str | None = Header(default=None)):
    check_secret(x_api_secret)

    answer_text = clean_answer(payload.answer)

    with closing(db()) as conn:
        conn.execute(
            "INSERT INTO answers (user_id, question_id, answer) VALUES (?, ?, ?)",
            (payload.user_id, payload.question_id, answer_text),
        )
        conn.commit()

    return {"ok": True}


# Optional form/query-friendly endpoint for integrations that cannot send JSON.
# It still stores only user_id, question_id and answer.
@app.post("/api/v1/answer-form")
async def save_answer_form(request: Request, x_api_secret: str | None = Header(default=None)):
    check_secret(x_api_secret)
    form = await request.form()

    user_id = str(form.get("user_id", ""))
    question_id = str(form.get("question_id", ""))
    answer = form.get("answer", "")

    if not user_id or not question_id:
        raise HTTPException(status_code=400, detail="user_id and question_id are required")

    answer_text = clean_answer(answer)

    with closing(db()) as conn:
        conn.execute(
            "INSERT INTO answers (user_id, question_id, answer) VALUES (?, ?, ?)",
            (user_id, question_id, answer_text),
        )
        conn.commit()

    return {"ok": True}
