# MenuBuilder Answer Server

This server is intentionally small. It stores only:

- Telegram user ID
- your question ID
- the user's answer

It does NOT create an application-level activity table or intentionally store
normal bot messages, menu navigation, or unrelated button clicks.

## API

POST `/api/v1/answer`

Header:
`X-API-Secret: YOUR_SECRET`

JSON body:
```json
{
  "user_id": "123456789",
  "question_id": "Q1",
  "answer": "Computer"
}
```

For a multi-answer response, `answer` can be an array:
```json
{
  "user_id": "123456789",
  "question_id": "Q2",
  "answer": ["Computer", "Economics"]
}
```

The database stores the array as JSON text.

## MenuBuilder mapping

MenuBuilder documents that macros can be used as request values. Its user ID
macro is `%userid%`. Create one variable per question, for example:

- `q1_answer`
- `q2_answer`
- `q3_answer`

Then your API request data should conceptually be:

```text
user_id=%userid%
question_id=Q1
answer=%q1_answer%
```

Use a POST request and send the API secret in the supported request/header field
if your MenuBuilder API Module exposes headers. If your API Module cannot set
headers, use a secret request parameter and adjust the endpoint accordingly;
do not put the secret in a public message.

## Local test

Install dependencies:
`pip install -r requirements.txt`

Set:
`API_SECRET=test-secret`

Run:
`uvicorn app:app --reload`

Then POST to:
`http://127.0.0.1:8000/api/v1/answer`

## Important

The server cannot be made publicly reachable just by creating these files.
It must be deployed on a hosting service that gives you an HTTPS URL.

Do not put your Telegram BotFather token in this project.
This server does not need the Telegram bot token.
